class ScraperException(Exception):
    pass
