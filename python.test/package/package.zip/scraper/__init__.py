from .scraper import *

# Version of the google-play-scraper-py package.
__version__ = "0.2.4"
