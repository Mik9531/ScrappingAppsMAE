import scraper


def lambda_handler(event, context):
    scraper.list(category='TOP_FREE')


